# -*- coding: utf-8 -*-
__author__ = 'chinfeng'

from .main import (
    on_activate,
    on_deactivate,
)