# -*- coding: utf-8 -*-
__author__ = 'chinfeng'

from gumpy.deco import *
import logging
logger = logging.getLogger(__name__)

@activate
def on_activate():
    logger.debug('zip_bdl activate')

@deactivate
def on_deactivate():
    logger.debug('zip_bdl deactivate')