export default angular.module('arp.sample.route', ['ngRoute'])
    .config(['$routeProvider', function ($routeProvider) {
        $routeProvider
            .when('/:page', {
                templateUrl: function (params) {
                    return params.page;
                }
            })
            .otherwise({
                redirectTo: '/auth.html'
            });
    }]);
