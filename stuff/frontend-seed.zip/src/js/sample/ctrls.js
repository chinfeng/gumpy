import authBiz from '../biz/auth';

export default angular.module('arp.sample.ctrls', [authBiz.name])
    .controller('AuthController', ['$scope', 'authApi', function ($scope, authApi) {
        $scope.user = {};
        $scope.ret = {};

        $scope.register = function (user) {
            authApi.register(user).then(
                function (data) {
                    $scope.ret = angular.extend({'功能': '注册', '执行': '成功'}, data);
                },
                function (data) {
                    $scope.ret = angular.extend({'功能': '注册', '执行': '失败'}, data);
                }
            );
        };

        $scope.login = function (user) {
            authApi.login(user).then(
                function (data) {
                    $scope.ret = angular.extend({'功能': '登陆', '执行': '成功'}, data);
                },
                function (data) {
                    $scope.ret = angular.extend({'功能': '登陆', '执行': '失败'}, data);
                }
            );
        };

        $scope.logout = function () {
            authApi.logout().then(
                function (data) {
                    $scope.ret = angular.extend({'功能': '注销', '执行': '成功'}, data);
                }
            );
        };

        $scope.me = function () {
            authApi.me().then(
                function (data) {
                    $scope.ret = angular.extend({'功能': '我的', '执行': '成功'}, data);
                },
                function (data) {
                    $scope.ret = angular.extend({'功能': '我的', '执行': '失败'}, data);
                }
            );
        };
    }])

    .controller('TreeShowcastController', ['$scope', function ($scope) {
        $scope.tree = [
            {
                text: '广东省',
                children: [
                    {text: '广州市', children: [{text: '越秀区', link: '#越秀'}, {text: '天河区', link: '#天河'}]},
                    {text: '东莞市'}
                ]
            },
            {
                text: '浙江省',
                children: [
                    {text: '杭州市', link: '#杭州'},
                    {text: '宁波市', link: '#杭州'}
                ]
            }
        ];
    }]);