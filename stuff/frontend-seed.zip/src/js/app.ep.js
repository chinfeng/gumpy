/* 组件库 */
import treeComp from './comp/tree';

/* 应用的具体业务 */
import routeCfg from './sample/route';
import ctrls from './sample/ctrls';

angular.module('app', [
    treeComp.name,
    routeCfg.name,
    ctrls.name
]);