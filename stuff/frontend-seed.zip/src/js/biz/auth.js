export default angular.module('arp.biz.auth', [])
    .service('authApi', ['$http', '$q', function ($http, $q) {
        this.register = function (user) {
            var deferred = $q.defer();
            $http.post('/mock/register', user)
                .success(function (data) {
                    deferred.resolve(data);
                })
                .error(function (data) {
                    deferred.reject(data);
                });
            return deferred.promise;
        };

        this.login = function (user) {
            var deferred = $q.defer();
            $http.post('/mock/login', user)
                .success(function (data) {
                    deferred.resolve(data);
                })
                .error(function (data) {
                    deferred.reject(data);
                });
            return deferred.promise;
        };

        this.logout = function () {
            var deferred = $q.defer();
            $http.post('/mock/logout')
                .success(function (data) {
                    deferred.resolve(data);
                })
                .error(function (data) {
                    deferred.reject(data);
                });
            return deferred.promise;
        };

        this.me = function () {
            var deferred = $q.defer();
            $http.get('/mock/me')
                .success(function (data) {
                    deferred.resolve(data);
                })
                .error(function (data) {
                    deferred.reject(data);
                });
            return deferred.promise;
        };
    }]);