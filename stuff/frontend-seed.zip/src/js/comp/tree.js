var tree_template = `
<ul>
    <li ng-repeat="node in ngModel">
        <div arp-tree-draggable-node="node">
            <a href="{{node.link || 'javascript:void(0)'}}">{{node.text}}</a>
        </div>
        <arp-tree-children ng-model="node.children"></arp-tree-children>
    </li>
</ul>
`;

export default angular.module('arp.comp.tree', [])
    .directive('arpTree', function () {
        return {
            restrict: 'E',
            template: tree_template,
            require: 'ngModel',
            scope: {
                ngModel: '='
            },
            link: function (scope, element, attrs, ctrl) {
                scope.rootNode = ngModel;
            }
        };
    })

    .directive('arpTreeChildren', ['$compile', function ($compile) {
        return {
            restrict: 'E',
            require: 'ngModel',
            scope: {
                ngModel: '='
            },
            link: function (scope, element, attrs, ctrl) {
                if (scope.ngModel) {
                    var sub = angular.element('<arp-tree ng-model="ngModel"></arp-tree>');
                    element.append(sub);
                    $compile(sub)(scope);
                }
            }
        };
    }])

    .directive('arpTreeDraggableNode', function () {

        return {
            restrict: 'A',
            scope: false,
            link: function (scope, element, attrs, ctrl) {
                var parentNode = scope.ngModel;
                var node = scope.$eval(attrs.arpTreeDraggableNode);

                angular.element(element).bind('dragstart', function(evt) {
                    evt.dataTransfer.effectAllowed = 'move';
                    // TODO: 将本级的 parentNode 和 node 传递到 dataTranfer 中
                    return false;
                });

                angular.element(element).bind("dragend", function(evt) {
                    evt.preventDefault();
                });

                angular.element(element).bind("dragover", function(evt) {
                    evt.preventDefault();
                });

                angular.element(element).bind("drop", function(evt) {
                    evt.preventDefault();
                    // TODO: 处理传递过来的 parent、node ，放置到 target 的 children 中
                });
            }

        };
    });