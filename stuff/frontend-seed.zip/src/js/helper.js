export function getAppName() {
    return document.querySelector('[ng-app]').getAttribute('ng-app');
}

export function fakeUUID() {
    var id = setTimeout(function () {}, 0);
    clearTimeout(id);
    return id;
}
