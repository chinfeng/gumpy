# NG 框架模板 #

## 安装 ##

    1. 准备环境（安装 node.js/io.js），检查：

        > node -v
        > npm -v

    2. 安装 gulp 工具：

        > npm install -g gulp

    3. 安装配套工具（到安装目录下）：

        > npm install

    4. 运行构建自动化任务：

        > gulp watch

    5. 进行开发。

    6. 附加任务参数：

      * --esnext  es6 支持
      * --dest <dir>  目标文件夹
      * --release 压缩、删除源码映射
      * test  运行 .spec.js 的单元测试

## 物理结构 ##

    1. package.json 、Gulpfile.js 、bower.json 为自动化工具配置

    2. src/assets 静态 html、json、css 等文件，这一目录的所有文件会自动复制到构建目录中

    3. src/js 源码文件，只对 .ep.js（entrypoint） 入口文件进行处理，每个入口都会构建、打包成一个 js 文件

    4. src/less 样式表，除去 .fragment.less、.mixin.less 等片段包含文件外，每个文件都会打包成一个 css 文件

    5. src/tmpl 支持 ejs/jade 模板，自动构建成为 html 文件

## 逻辑结构 ##

    参见文件：sample.jade/sample.html：

    1. 使用了 app.ep.min.js/app.ep.js 作为主入口

    2. app.ep.js 中依赖了 sample、comp 中的模块

    3. sample 中的模块，依赖了 biz 中的模块

    4. 结构：comp 组件，biz 为业务，sample 为应用，其中，comp 与 biz 不相互关联，主要在 sample 的层面作业务-组件的关联

    5. mock.ep.js 为模拟后端文件

## SPA 作业流程 ##

    1. 按照具体的方式放置代码文件

    2. 如果编写 js 文件，请主要在 app.ep.js 中加入模块引用

## MSPA 作业流程 ##

    MSPA 即多个单页应用的结构

    1. 每个页面匹配一个 .ep.js 文件

    2. 如果有多层次的依赖关系，可自行组织中间的依赖层
