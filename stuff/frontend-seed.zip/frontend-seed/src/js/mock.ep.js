import {getAppName, fakeUUID} from './helper';

angular.module(getAppName()).requires.push('arp.sample.mock');
angular.module('arp.sample.mock', ['ngMockE2E'])
    .run(['$httpBackend', function ($httpBackend) {
        /* 略过所有的静态文件 */
        $httpBackend.whenGET(/.*\.html$/).passThrough();
        $httpBackend.whenGET(/.*\.jpg$/).passThrough();
        $httpBackend.whenGET(/.*\.png$/).passThrough();
        $httpBackend.whenGET(/.*\.json$/).passThrough();

        /* 样例：模拟注册、登陆 */
        var users = {};
        var currentUser = null;
        $httpBackend.whenPOST('/mock/register').respond(function (method, url, data) {
            data = angular.fromJson(data);
            if (users[data.username]) {
                return [400, {reason: '用户已注册'}, {}];
            } else {
                var uuid = fakeUUID();
                users[data.username] = angular.extend({uid: uuid}, data);
                return [200, {uid: uuid}, {}];
            }
        });
        $httpBackend.whenPOST('/mock/login').respond(function (method, url, data) {
            data = angular.fromJson(data);
            if (users.hasOwnProperty(data.username) && (users[data.username].password == data.password)) {
                currentUser = users[data.username];
                return [200, {uid: users[data.username].uid}, {}];
            } else {
                return [400, {reason: '用户不存在，或密码错误'}, {}];
            }
        });
        $httpBackend.whenPOST('/mock/logout').respond(function () {
            currentUser = null;
            return [200, {logout: 'ok'}, {}];
        });
        $httpBackend.whenGET('/mock/me').respond(function () {
            return currentUser ?
                [200, currentUser, {'content-type': 'application/json'}] :
                [401, {reason: '未登陆'}, {}];
        });
    }]);
