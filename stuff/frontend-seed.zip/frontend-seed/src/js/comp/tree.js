var tree_template = `
<ul>
  <li ng-repeat="node in ngModel">
    <div arp-tree-draggable-node="node" draggable="true" arp-tree-children="node.children">
      <span style="cursor:pointer">{{node.text}}</span>
    </div>
  </li>
</ul>
`;

var nodeReferences = [];
var nodeId = -1;

export default angular.module('arp.comp.tree', [])

    .directive('arpTree', function () {
        return {
            restrict: 'E',
            template: tree_template,
            require: 'ngModel',
            scope: {
                ngModel: '=',
                parentNode: '=?'
            }
        };
    })

    .directive('arpTreeChildren', ['$compile', function ($compile) {
        return {
            restrict: 'A',
            link: function (scope, element, attrs) {
                var children = scope.$eval(attrs.arpTreeChildren);
                if (children) {
                    var sub = angular.element('<arp-tree ng-model="node.children" parent-node="node"></arp-tree>');
                    element.append(sub);
                    $compile(sub)(scope);
                }
            }
        };
    }])

    .directive('arpTreeDraggableNode', function () {
        return {
            restrict: 'A',
            link: function (scope, element, attrs) {
                var node = scope.$eval(attrs.arpTreeDraggableNode);
                var nid = nodeId++;
                nodeReferences[nid] = {
                    node: node,
                    siblings: scope.ngModel
                };  // 保存对象引用

                element.bind('dragstart', function(evt) {
                    evt.dataTransfer.effectAllowed = 'move';
                    element.addClass('dragging');
                    evt.dataTransfer.setData('nodeId', nid);
                    evt.stopPropagation();
                });

                element.bind("dragend", function(evt) {
                    element.removeClass('dragging');
                    evt.preventDefault();
                });

                element.bind("dragover", function(evt) {
                    evt.preventDefault();
                });

                element.bind("drop", function(evt) {
                    var nid = evt.dataTransfer.getData('nodeId');
                    scope.$apply(function () {
                        moveBelow(
                            nodeReferences[nid].siblings, nodeReferences[nid].node,
                            scope.ngModel, node
                        );
                    });
                    evt.preventDefault();
                    evt.stopPropagation();

                });
            }
        };

        function moveBelow(srcSiblings, srcNode, destSiblings, destNode) {
            var srcIdx = srcSiblings.indexOf(srcNode);
            var destIdx = destSiblings.indexOf(destNode);
            var node = srcSiblings.splice(srcIdx, 1)[0];
            destSiblings.splice(destIdx + 1, 0, node);
        }
    });
