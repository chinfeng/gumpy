describe("单元测试模板", function() {
    beforeEach(module('arp.biz.auth'));

    it('服务 authApi 注入', inject(function(authApi){
        expect(authApi).not.toBeUndefined();
    }));

    it("其他测试", function() {
        expect(true).toBe(true);
    });
});
