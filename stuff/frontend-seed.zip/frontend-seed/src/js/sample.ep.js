/* 组件库 */
import treeComp from './comp/tree';

/* 应用的具体业务 */
import routeCfg from './sample/route';
import ctrls from './sample/ctrls';

angular.module('app', [
    routeCfg.name,
    ctrls.name,
    treeComp.name
]);
