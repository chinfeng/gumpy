var os = require('os');
var path = require('path');
var spawn = require('child_process').spawn;

var gulp = require('gulp');
var gutil = require('gulp-util');

var uglify = require('gulp-uglify');
var browserify = require('gulp-browserify');
var sourcemaps = require('gulp-sourcemaps');

var jshint = require('gulp-jshint');
var karma = require('karma');

var merge = require('merge-stream');
var es6ify = require('es6ify');

var less = require('gulp-less');
var cssmin = require('gulp-cssmin');
var rename = require('gulp-rename');

var ejs = require('gulp-ejs');
var jade = require('gulp-jade');
var minifyHTML = require('gulp-minify-html');

var gulpif = require('gulp-if');

var debug = !(gutil.env.hasOwnProperty('release') || false);
var esnext = gutil.env.hasOwnProperty('esnext') || false;
var withoutMock = gutil.env.hasOwnProperty('without-mock') || false;
var dest = gutil.env.dest || 'dest';

gulp.task('default', ['lint', 'less', 'tmpl', 'assets', 'js', 'vendor']);

/* 语法检查任务 */
gulp.task('lint', function () {
    return merge(
        gulp.src('src/js/**/*.js')
            .pipe(jshint({globals: {angular: false, name: true}, jasmine: true, browser: true, esnext: true}))
            .pipe(jshint.reporter('default')),
        gulp.src('Gulpfile.js')
            .pipe(jshint())
            .pipe(jshint.reporter('default'))
    );
});

/* 复制静态文件 */
gulp.task('assets', function () {
    return gulp.src('src/assets/**/*')
        .pipe(gulp.dest(path.join(dest, 'assets')));
});

/* less */
gulp.task('less', function () {
    return gulp.src(['src/less/**/*.less', '!src/less/**/*.fragment.less', '!src/less/**/*.mixin.less'])
        .pipe(gulpif(debug, sourcemaps.init({loadMps: true})))
        .pipe(less())
        .on('error', errorHandler)
        .pipe(cssmin())
        .pipe(rename({suffix: '.min'}))
        .pipe(gulpif(debug, sourcemaps.write()))
        .pipe(gulp.dest(path.join(dest, 'css')));
});

/* EJS、JADE模板 */
gulp.task('tmpl', function () {
    return merge(
        gulp.src(['src/tmpl/*.ejs', '!src/tmpl/*.fragment.ejs', '!src/tmpl/*.layout.ejs'])
            .pipe(ejs({esnext: esnext, mock: !withoutMock}))
            .on('error', errorHandler)
            .pipe(gulpif(!debug, minifyHTML()))
            .pipe(gulp.dest('dest')),
        gulp.src(['src/tmpl/*.jade', '!src/tmpl/*.fragment.jade', '!src/tmpl/*.layout.jade'])
            .pipe(jade({locals: {esnext: esnext, mock: !withoutMock}}))
            .on('error', errorHandler)
            .pipe(gulpif(!debug, minifyHTML()))
            .pipe(gulp.dest('dest'))
    );
});

/* javascript */
gulp.task('js', ['lint'], function () {
    return gulp.src('src/js/**/*.ep.js')
        .pipe(browserify(esnext ? {debug: debug, transform: es6ify} : {debug: debug}))
        .on('error', errorHandler)
        .pipe(gulpif(debug, sourcemaps.init({loadMaps: true})))
        .pipe(gulpif(!debug, uglify()))
        .pipe(gulpif(debug, sourcemaps.write()))
        .pipe(rename({suffix: '.min'}))
        .pipe(gulp.dest(path.join(dest, 'js')));
});

/* 开发库依赖 */
gulp.task('vendor', function () {
    var jquery = gulp.src(['bower_components/jquery/dist/**/*.min.js'])
        .pipe(gulp.dest(path.join(dest, 'vendor/jquery')));
    var angular = gulp.src(['bower_components/angular*/**/*.min.js', 'bower_components/angular-mocks/angular-mocks.js'])
        .pipe(rename({dirname: ''}))
        .pipe(gulp.dest(path.join(dest, 'vendor/angular')));
    var bootstrap = gulp.src('bower_components/bootstrap/dist/**/*')
        .pipe(gulp.dest(path.join(dest, 'vendor/bootstrap')));
    var traceur = gulp.src('node_modules/traceur/bin/traceur-runtime.js')
        .pipe(gulp.dest(path.join(dest, 'vendor/traceur')));
    return merge(jquery, bootstrap, angular, traceur);
});

/* 单元测试 */
gulp.task('test', ['js'], function (done) {
    return karma.server.start({
        frameworks: ['jasmine'],
        browsers: ['PhantomJS'],
        reporters: ['mocha'],
        files: [
            'bower_components/angular/angular.min.js',
            'bower_components/angular-mocks/angular-mocks.js',
            dest + '/js/**/*.js',
            'src/js/**/*.spec.js',
            '!' + dest + '/js/mock*.js'
        ],
        singleRun: true
    }, function () { done(); });
});

/* 构建自管理 */
gulp.task('auto-reload', function () {
    var proc;

    function restart() {
        if (proc) {
            proc.kill();
        }
        if (os.platform() === 'win32') {
            proc = spawn('cmd', ['/s', '/c', 'gulp'], {stdio: 'inherit'});
        } else {
            proc = spawn('gulp', [], {stdio: 'inherit'});
        }
    }

    gulp.watch('Gulpfile.js', restart);
    restart();
});

/* 监听自动化 */
gulp.task('watch', ['default'], function () {
    gulp.watch(['src/js/**/*.js', 'src/js/**/*.es6'], ['js']);
    gulp.watch(['src/tmpl/**/*.ejs', 'src/tmpl/**/*.jade'], ['tmpl']);
    gulp.watch('src/less/**/*.less', ['less']);
    gulp.watch(['bower_components/**/*.js', 'bower_components/**/*.css'], ['vendor']);
    gulp.watch('src/assets/**/*', ['assets']);
});

function errorHandler(error) {
    console.log(error.toString());
    this.emit('end');
}
